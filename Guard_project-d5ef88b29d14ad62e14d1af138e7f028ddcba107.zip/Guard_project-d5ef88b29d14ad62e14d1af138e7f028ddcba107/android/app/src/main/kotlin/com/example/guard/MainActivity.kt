package com.example.guard

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
